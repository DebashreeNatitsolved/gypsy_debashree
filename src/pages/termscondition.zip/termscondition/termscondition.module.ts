import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TermsconditionPage } from './termscondition';

@NgModule({
  declarations: [
    TermsconditionPage,
  ],
  imports: [
    IonicPageModule.forChild(TermsconditionPage),
  ],
})
export class TermsconditionPageModule {}
